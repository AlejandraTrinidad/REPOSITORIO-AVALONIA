using Avalonia.Controls;
using Avalonia.Interactivity;
namespace ProyectoDos;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }

        private void OnButtonClick(object sender, RoutedEventArgs e) {}
}